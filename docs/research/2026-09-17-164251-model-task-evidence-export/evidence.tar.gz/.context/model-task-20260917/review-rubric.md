# Model-task review rubric v1

Freeze before inspecting candidate output. Development sources are consumed examples, not an unseen accuracy sample. Review only supplied source and stored context. Hide candidate identity and old model predictions from independent reviewers.

## Translation

For every generated EN, Simplified Chinese, and Japanese output, check the entire source, including paragraphs. Preserve speaker/subject/object, direction of comparisons, negation, uncertainty, conditional language, names, handles, links, numerical quantities, currency (do not infer an unstated currency), tone, idioms and quoted versus adopted claims. Natural wording is allowed; do not demand word-for-word agreement. Do not fact-check or correct the author's claims. A transliteration, opaque proper name, or source ambiguity is not automatically an error. Preserve line breaks and paragraph boundaries and remove only the protocol markers. Native-language copies must be exact. Missing targets and structural validation rejection remain coverage failures.

## Commentary

Check all three locales against the post and available quote/parent. Commentary should explain meaning or significance without inventing context. Reasonable interpretation must remain proportional to source evidence. Do not invent model identity, platform credibility, external facts, product capabilities, causal explanations, or wider eligibility for offers. Preserve speculation as speculation and the author's stance as their stance. All three locales must express compatible interpretations. Commentary need not repeat every source detail, and compression is not an omission unless it changes the explanation. Do not penalize grounded interpretation merely because it is not a literal translation.

## Classification

Use the exact frozen current prompts and enum definitions, plus accepted owner rules. Assess each target brand separately and every applicable axis. Missing secondary labels, extra unsupported labels, wrong scalar values, misattributed promotions, and unsupported context-missing outcomes are errors. Reviewed official/staff relationships are evidence, not automatic content labels. Historical labels only cover the dimensions and fields actually reviewed; blank owner answers are unknown. Old taxonomy labels cannot serve as a complete reference for new dimensions. Valid extra labels may expose a stale reference rather than a candidate error. Record and adjudicate each difference instead of equating reference agreement with accuracy.

## Review record and scoring

Record one finding per affected output: post_id, task, locale/brand/axis, severity (material/minor/uncertain), exact source span, exact output span, explanation, and defensible correction. Record reviewed-good outputs explicitly, so absence of a finding cannot imply review completion. Genuine minor errors count; purely stylistic preferences do not. Two independent reviews and parent reconciliation are required for qualification; unresolved findings stay unknown and prevent acceptance. No further owner labeling is required by this experiment.

The primary denominator is all selected source posts. Count a source post once if any required result has a confirmed semantic or structural defect, transport failure, missing output, or pre-call exclusion. Qualification requires at most 1% erroneous source posts in each cohort, complete assessment, and the plan's cost/latency gates. Report per-locale/output rates separately. Eight- or 24-case diagnostics require zero erroneous posts to meet this threshold, but cannot establish a population error rate. A passing diagnostic only advances to regression and fresh qualification.
